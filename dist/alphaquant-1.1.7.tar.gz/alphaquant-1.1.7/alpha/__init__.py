# -*- coding:utf-8 -*-

"""
Asynchronous driven quantitative trading framework.
Author: QiaoXiaofeng
Date:   2020/05/26
Email:  andyjoe318@gmail.com
"""

__author__ = "QiaoXiaofeng"
__version__ = (1, 0, 5)